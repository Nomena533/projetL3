import { useEffect, useRef, useState } from "react";
import { HiOutlinePaperAirplane } from "react-icons/hi2";
import AnimatedSection from "../../components/AnimatedSection";
import {
  markConversationAsRead,
  storeMessage,
} from "../../app/api/messageApi";
import { useUser } from "../../app/hooks/useUser";
import { useMessage } from "../../app/hooks/useMessage";
import { useLang } from "../../app/hooks/useLang";
import { ActionFeedback, DataGate } from "../../components/AsyncState";
import useAsyncAction from "../../app/hooks/useAsyncAction";

function MessagesContent() {
  const { t } = useLang();
  const [activeProf, setActiveProf] = useState(null);
  const [draft, setDraft] = useState("");
  const { conversations, fetchMessages, loading } = useMessage();
  // Envoi d'un message (spinner plein écran + erreur avec « Réessayer »)
  const action = useAsyncAction();
  const { userList } = useUser();
  const professeurs = userList.filter(
    (user) => user.role?.name === "professeur",
  );

  console.log("Conversations : ", conversations);

  useEffect(() => {
    if (professeurs.length === 0) {
      setActiveProf(null);
      return;
    }

    setActiveProf(
      (current) =>
        professeurs.find((professeur) => professeur.id === current?.id) ||
        professeurs[0],
    );
  }, [userList]);

  const activeConversation =
    conversations.find(
      (conversation) => conversation.otherUserId === activeProf?.id,
    ) || null;

  const messagesEndRef = useRef(null);

  useEffect(() => {
    // Fait défiler la boîte de discussion vers le bas à chaque changement de
    // conversation ou d'arrivée d'un nouveau message, pour que le dernier
    // message envoyé ou reçu reste visible en bas.
    messagesEndRef.current?.scrollIntoView({ block: "end" });
  }, [activeConversation?.messages, activeProf?.id]);

  useEffect(() => {
    if (!activeConversation?.unreadCount) return;

    // La conversation ouverte automatiquement suit la même règle de lecture qu'une conversation cliquée.
    const markAsRead = async () => {
      await markConversationAsRead(activeConversation.otherUserId);
      await fetchMessages();
    };

    markAsRead().catch(() => {});
  }, [activeConversation, fetchMessages]);

  console.log("activeProf : ", activeProf);
  console.log("activeConversation : ", activeConversation);

  const handleSend = () => {
    const content = draft.trim();
    if (!content || !activeProf) return;

    return action.run("Envoi du message", async () => {
      await storeMessage({ receiver_id: activeProf.id, content });
      setDraft("");
      // Un échec du rafraîchissement ne doit pas relancer l'envoi (« Réessayer »).
      await Promise.resolve(fetchMessages()).catch(() => {});
    });
  };

  const handleProfessorSelect = (professeur) => {
    setActiveProf(professeur);

    // Le clic ouvre la discussion; l'effet ci-dessus synchronise ensuite son statut lu.
  };

  return (
    <div className="space-y-6">
      <ActionFeedback action={action} />
      <AnimatedSection>
        <span className="font-mono text-xs uppercase tracking-widest text-coral-dark">{t("Espace élève")}</span>
        <h2 className="mt-2 font-display text-2xl font-semibold text-ink sm:text-3xl">{t("Messages")}</h2>
      </AnimatedSection>
      <AnimatedSection
        className="grid overflow-hidden rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10 md:grid-cols-3"
        style={{ minHeight: "480px" }}
      >
        <div className="divide-y divide-ivory-dark border-b border-ivory-dark md:border-b-0 md:border-r">
          <div className="border-b border-ivory-dark px-5 py-4">
            <p className="font-mono text-[10px] uppercase tracking-widest text-coral-dark">{t("Nouveau message")}</p>
            <p className="mt-1 font-display text-base font-semibold text-ink">{t("Choisir un professeur")}</p>
          </div>
          {professeurs.map((professeur) => (
            // Une ligne peut exister avant le premier message; on cherche donc le compteur par identifiant.
            (() => {
              const conversation = conversations.find(
                (item) => item.otherUserId === professeur.id,
              );

              return (
            <button
              key={professeur.id}
              onClick={() => handleProfessorSelect(professeur)}
              className={`w-full px-5 py-4 text-left transition-colors duration-200 ${
                activeProf?.id === professeur.id
                  ? "bg-coral/10"
                  : "hover:bg-ivory-dark/40"
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-ivory-dark font-display text-xs font-semibold text-coral-dark">
                  {professeur.name?.slice(0, 1).toUpperCase()}
                  {professeur.firstname?.slice(0, 1).toUpperCase()}
                </span>
                <div className="min-w-0">
                  <p className="truncate font-body text-sm font-semibold text-ink">
                    {professeur.name} {professeur.firstname}
                  </p>
                  <p className="mt-0.5 truncate font-body text-xs text-ink-soft">{t("Professeur")}</p>
                  {conversation?.unreadCount > 0 && (
                    // Ce badge indique le nombre de réponses du professeur restant à lire.
                    <span className="mt-1 inline-flex min-w-5 items-center justify-center rounded-full bg-coral px-1.5 py-0.5 font-mono text-[10px] font-semibold leading-none text-white">
                      {conversation.unreadCount > 9
                        ? "9+"
                        : conversation.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </button>
                );
              })()
          ))}
          {professeurs.length === 0 && (
            <p className="px-5 py-8 font-body text-sm text-ink-soft">{t("Chargement des professeurs…")}</p>
          )}
        </div>

        <div className="flex flex-col md:col-span-2">
          {loading ? (
            <div className="grid flex-1 place-items-center p-6 text-center">
              <p className="font-body text-sm text-ink-soft">{t("Chargement des conversations…")}</p>
            </div>
          ) : activeProf ? (
            <>
              <div className="border-b border-ivory-dark px-6 py-4">
                <p className="font-display text-sm font-semibold text-ink">
                  {activeProf.name} {activeProf.firstname}
                </p>
                <p className="font-mono text-[11px] uppercase tracking-wide text-ink-soft">{t("Professeur · Accompagnement personnalisé")}</p>
              </div>
              <div
                className="flex-1 space-y-3 overflow-y-auto p-6"
                style={{ maxHeight: "360px" }}
              >
                {activeConversation?.messages?.length ? (
                  <>
                    {activeConversation.messages.map((message) => {
                      const isRecu = message.sender_id === activeProf.id;
                      return (
                        <div
                          key={message.id}
                          className={`flex flex-col ${isRecu ? "items-start" : "items-end"}`}
                        >
                          <div
                            className={`max-w-xs rounded-2xl px-4 py-2.5 font-body text-sm shadow-sm ${
                              isRecu
                                ? "rounded-bl-sm border border-ivory-dark bg-white text-ink"
                                : "rounded-br-sm bg-coral text-white"
                            }`}
                          >
                            {message.content}
                          </div>
                          <span
                            className={`mt-1 font-mono text-[10px] uppercase tracking-wide ${
                              isRecu ? "text-ink-soft" : "text-coral-dark"
                            }`}
                          >
                            {isRecu ? t("Reçu") : t("Envoyé")}
                          </span>
                        </div>
                      );
                    })}
                    {/* Ancre invisible utilisée pour faire défiler jusqu'au dernier message. */}
                    <div ref={messagesEndRef} />
                  </>
                ) : (
                  <p className="font-body text-sm text-ink-soft">{t("Aucun message dans cette conversation.")}</p>
                )}
              </div>
              <div className="flex items-center gap-2 border-t border-ivory-dark p-4">
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={t("Écrire un message…")}
                  className="flex-1 rounded-full border border-ivory-dark bg-white/70 dark:bg-white/10 px-4 py-2.5 font-body text-sm text-ink outline-none transition-colors duration-300 focus:border-coral"
                />
                <button
                  onClick={handleSend}
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-coral text-ivory shadow-md shadow-coral/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-coral-dark"
                  aria-label={t("Envoyer")}
                >
                  <HiOutlinePaperAirplane size={15} />
                </button>
              </div>
            </>
          ) : (
            <div className="grid flex-1 place-items-center p-6 text-center">
              <p className="font-body text-sm text-ink-soft">{t("Sélectionne un professeur pour ouvrir la discussion.")}</p>
            </div>
          )}
        </div>
      </AnimatedSection>
    </div>
  );
}

export default function Messages() {
  const messages = useMessage();
  const users = useUser();

  return (
    <DataGate
      sources={[
        {
          label: "Chargement des messages",
          loading: messages.loading,
          error: messages.error,
          retry: messages.fetchMessages,
        },
        {
          label: "Chargement des contacts",
          loading: users.loading,
          error: users.error,
          retry: users.fetchUserList,
        },
      ]}
    >
      <MessagesContent />
    </DataGate>
  );
}
