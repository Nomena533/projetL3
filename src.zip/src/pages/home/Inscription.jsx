import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import {
  HiOutlineCheckCircle,
  HiOutlineClock,
  HiOutlineAcademicCap,
} from "react-icons/hi2";
import AnimatedSection from "../../components/AnimatedSection";
import { useAuth } from "../../app/hooks/useAuth";
import { useLevel } from "../../app/hooks/useLevel";
import { useInstrument } from "../../app/hooks/useInstrument";
import { storeInscription } from "../../app/api/inscriptionApi";
import { getUserListInscription } from "../../app/api/userApi";
import { useUser } from "../../app/hooks/useUser";
import { FaMoneyBill, FaMoneyBillAlt, FaMoneyBillWave, FaMoneyCheck } from "react-icons/fa";
import { useLang } from "../../app/hooks/useLang";
import { ActionFeedback, DataGate } from "../../components/AsyncState";
import useAsyncAction from "../../app/hooks/useAsyncAction";

function formatAriary(n) {
  return new Intl.NumberFormat("fr-MG").format(n) + " Ar";
}

function InscriptionContent() {
  const { t } = useLang();
  const [params] = useSearchParams();
  const niveauName = params.get("niveau") || "initiation";
  const navigate = useNavigate();
  const isInitiation = niveauName === "initiation";
  const [niveau, setNiveau] = useState(null);
  const [inscriptionId, setInscriptionId] = useState(0);

  const handlePaiement = () => {
    navigate(
      `/paiement?inscriptionId=${inscriptionId}&niveau=${niveau.name}&instruments=${instrumentsParam}`,{replace:true}
    );
  }

  const { user } = useAuth();

  const { userListInscription, fetchUserListInscription } =
    useUser();

  // Chargement des inscriptions (plein écran + erreur « Réessayer ») et envoi du formulaire
  const load = useAsyncAction({ initialPending: true, initialLabel: "Chargement de vos inscriptions" });
  const action = useAsyncAction();

  const charger = () =>
    load.run("Chargement de vos inscriptions", () => fetchUserListInscription(user.id));

  useEffect(() => {
    charger();
  }, [user]);

  console.log("userListInscription : ", userListInscription);

  const [form, setForm] = useState({
    telephone: user.telephone || "",
    montant: "",
  });

  const { levels } = useLevel();
  
  // "instruments" = catalogue complet récupéré depuis la BDD (via le Provider).
  // Ne pas confondre avec la sélection de l'utilisateur, qui est gérée séparément.
  const { instruments } = useInstrument();

  useEffect(() => {
    if (levels && levels.length > 0) {
      const found =
        levels.find((level) => level.name === niveauName) || levels[0];
      setNiveau(found);
    }
  }, [levels, niveauName]);

  // Ids des instruments choisis par l'utilisateur dans le formulaire.
  // const [selectedInstruments, setSelectedInstruments] = useState([]);
  const [selectedInstruments, setSelectedInstruments] = useState([]);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  // // Cherche l'inscription du niveau initiation
  const inscriptionInitiation = userListInscription.find(
    (inscription) =>
      inscription.level.name.toLowerCase() === "initiation" &&
      inscription.instruments.length > 0,
  );

  console.log("inscriptionInitiation : ", inscriptionInitiation);

  // Remplissage automatique de selectedInstruments avec les ids des intruments de l'inscription sur le niveau initation
  useEffect(() => {
    // Cherche l'inscription du niveau initiation
    const inscriptionInitiation = userListInscription.find(
      (inscription) =>
        inscription.level.name.toLowerCase() === "initiation" &&
        inscription.instruments.length > 0,
    );

    if (inscriptionInitiation) {
      const instruments = inscriptionInitiation.instruments.map(
        (instrument) => ({
          id: instrument.id,
          name: instrument.name,
        }),
      );

      setSelectedInstruments(instruments);
    }
  }, [userListInscription]);

  const toggleInstrument = (id, name) => {
    setSelectedInstruments((list) => {
      const existe = list.some((instrument) => instrument.id === id);

      if (existe) {
        return list.filter((instrument) => instrument.id !== id);
      }

      return [...list, { id, name }];
    });
  };

  console.log("selectedInstruments : ", selectedInstruments);

  const nombreInstruments = selectedInstruments.length;

  // Montant = nombre d'instruments sélectionnés × prix mensuel du niveau
  const montantTotal = useMemo(
    () => (nombreInstruments * (niveau?.prix_mensuel || 0)) + parseFloat(niveau?.droit_inscription),
    [nombreInstruments, niveau],
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (nombreInstruments === 0) return;

    return action.run("Envoi de l'inscription", async () => {
      const data = {
        telephone: form.telephone,
        montant: montantTotal,
        instruments: selectedInstruments.map((instrument) => instrument.id),
      };

      const response = await storeInscription(niveau.id, data);

      console.log("Inscription réussie", response.data);

      setInscriptionId(response.data.inscription.id);

      // (nom, prenom, email, telephone, niveau: niveau.id, instruments: selectedInstruments)
      setSent(true);
    }, { errorMessage: t("Une erreur est survenue lors de l'inscription.") });
  };

  const instrumentsParam = selectedInstruments
    .map((instrument) => instrument.name.toLowerCase())
    .join(",");

  if (load.pending || load.error) {
    return <ActionFeedback action={load} variant="fetch" />;
  }

  if (!niveau) {
    return (
      <section className="px-5 py-16 sm:px-8 sm:py-20">
        <div className="mx-auto grid max-w-6xl gap-14 lg:grid-cols-[1fr_1.3fr]">
          <AnimatedSection>
            <p className="font-body text-sm text-ink-soft">{t("Chargement …")}</p>
          </AnimatedSection>
        </div>
      </section>
    );
  }

  return (
    <section className="px-5 py-16 sm:px-8 sm:py-20">
      <div className="mx-auto grid max-w-6xl gap-14 lg:grid-cols-[1fr_1.3fr]">
        <AnimatedSection>
          <span className="font-mono text-xs uppercase tracking-widest text-coral-dark">{t("Inscription")}</span>
          <h1 className="mt-3 font-display text-4xl font-semibold text-ink sm:text-5xl">{t("Rejoins la formation")}</h1>
          <p className="mt-4 max-w-sm font-body text-ink-soft">{t("Choisis le ou les instruments que tu veux apprendre. Ton parcours démarre dès validation de ton inscription.")}</p>

          <div className="mt-10 space-y-4 rounded-2xl border border-ivory-dark bg-white/60 dark:bg-white/10 p-6">
            <p className="font-mono text-[11px] uppercase tracking-wide text-coral-dark">{t("Formation concernée")}</p>
            <div className="flex items-center gap-3.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-coral/10 text-coral-dark">
                <HiOutlineAcademicCap size={19} />
              </span>
              <div>
                <p className="font-body text-sm font-semibold text-ink">{t("Niveau {{name}}", { name: niveau.name })}</p>
                <p className="font-body text-xs text-ink-soft">
                  {t(niveau.description)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-coral/10 text-coral-dark">
                <HiOutlineClock size={19} />
              </span>
              <div>
                <p className="font-body text-sm font-semibold text-ink">{t("Durée : {{duree}}", { duree: niveau.duree })}</p>
                {/* <p className="font-body text-xs text-ink-soft">
                  {formatAriary(niveau.prix_mensuel)} par mois par instrument
                </p> */}
              </div>
            </div>
            <div className="flex items-center gap-3.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-coral/10 text-coral-dark">
                <FaMoneyBillWave size={19} />
              </span>
              <div>
                <p className="font-body text-sm font-semibold text-ink">{t("Droit d'inscription : {{v0}}", { v0: formatAriary(niveau.droit_inscription) })}</p>
                <p className="font-body text-xs text-ink-soft">{t("{{v0}} par mois par instrument", { v0: formatAriary(niveau.prix_mensuel) })}</p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        <AnimatedSection
          delay={120}
          className="rounded-[1.75rem] border border-ivory-dark bg-white/60 dark:bg-white/10 p-8 sm:p-10"
        >
          {sent ? (
            <div className="flex flex-col items-center gap-3 py-10 text-center animate-fade-in">
              <HiOutlineCheckCircle className="text-coral-dark" size={44} />
              <h2 className="font-display text-xl font-semibold text-ink">{t("Inscription envoyée !")}</h2>
              <p className="max-w-sm font-body text-sm text-ink-soft">{t(
                nombreInstruments > 1
                  ? "Merci {{prenom}}, ton inscription au niveau {{name}} pour {{nombreInstruments}} instruments ({{montant}}) a bien été enregistrée. Un e-mail de confirmation arrive à {{email}}."
                  : "Merci {{prenom}}, ton inscription au niveau {{name}} pour {{nombreInstruments}} instrument ({{montant}}) a bien été enregistrée. Un e-mail de confirmation arrive à {{email}}.",
                { prenom: form.prenom || "", name: niveau.name, nombreInstruments, montant: formatAriary(montantTotal), email: form.email || t("ton adresse") },
              )}
              </p>
              <button onClick={handlePaiement}
                className="mt-3 font-body text-sm font-semibold text-coral-dark hover:text-brick"
              >{t("Finaliser le paiement pour cette inscription")}</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <ActionFeedback action={action} />
              {/* Informations élève */}
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">{t("Tes informations")}</h2>
                <div className="mt-4 grid gap-5 sm:grid-cols-2">
                  <label className="block">
                    <span className="font-body text-sm font-medium text-ink">{t("Nom")}</span>
                    <input
                      name="nom"
                      value={user.name}
                      onChange={handleChange}
                      required
                      placeholder={t("Rakoto")}
                      className="mt-1.5 w-full rounded-xl border border-ivory-dark bg-ivory px-4 py-2.5 font-body text-sm text-ink outline-none transition-colors focus:border-coral"
                    />
                  </label>
                  <label className="block">
                    <span className="font-body text-sm font-medium text-ink">{t("Prénom")}</span>
                    <input
                      name="prenom"
                      value={user.firstname}
                      onChange={handleChange}
                      required
                      placeholder={t("Fara")}
                      className="mt-1.5 w-full rounded-xl border border-ivory-dark bg-ivory px-4 py-2.5 font-body text-sm text-ink outline-none transition-colors focus:border-coral"
                    />
                  </label>
                  <label className="block">
                    <span className="font-body text-sm font-medium text-ink">{t("Email")}</span>
                    <input
                      type="email"
                      name="email"
                      value={user.email}
                      onChange={handleChange}
                      required
                      placeholder="vous@email.com"
                      className="mt-1.5 w-full rounded-xl border border-ivory-dark bg-ivory px-4 py-2.5 font-body text-sm text-ink outline-none transition-colors focus:border-coral"
                    />
                  </label>
                  <label className="block">
                    <span className="font-body text-sm font-medium text-ink">{t("Téléphone")}</span>
                    <input
                      type="tel"
                      name="telephone"
                      value={form.telephone}
                      onChange={handleChange}
                      required
                      placeholder="+261 34 00 000 00"
                      className="mt-1.5 w-full rounded-xl border border-ivory-dark bg-ivory px-4 py-2.5 font-body text-sm text-ink outline-none transition-colors focus:border-coral"
                    />
                  </label>
                </div>
              </div>

              {/* Choix des instruments */}
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">{t("Instruments à apprendre")}</h2>
                <p className="mt-1 font-body text-xs text-ink-soft">{t("Choix multiple possible.")}</p>
                {/* Liste verticale scrollable : reste lisible même si la liste
                    d'instruments s'agrandit une fois branchée sur la BDD. */}
                <div className="mt-4 max-h-72 divide-y divide-ivory-dark overflow-y-auto rounded-2xl border border-ivory-dark bg-ivory">
                  {instruments.map((instr) => {
                    const selected = selectedInstruments.some(
                      (instrument) => instrument.id === instr.id,
                    );
                    // const selected = selectedInstruments.includes(instr.id);

                    return (
                      <button
                        type="button"
                        key={instr.id}
                        onClick={() => {
                          if (!isInitiation) return; // empêche le clique
                          toggleInstrument(instr.id, instr.name);
                        }}
                        disabled={!isInitiation}
                        className={`flex w-full items-center gap-3 px-4 py-3 text-left transition-colors duration-200 ${
                          selected ? "bg-coral/10" : "hover:bg-ivory-dark/40"
                        }`}
                      >
                        <span className="text-xl"></span>
                        <span className="flex-1 font-body text-sm font-medium text-ink">
                          {instr.name}
                        </span>
                        <span
                          className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border transition-colors duration-200 ${
                            selected
                              ? "border-coral bg-coral text-ivory"
                              : "border-ivory-dark bg-white text-transparent"
                          }`}
                        >
                          <HiOutlineCheckCircle size={14} />
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Récapitulatif automatique */}
              <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-linear-to-br from-brick via-coral-dark to-coral p-5 text-ivory">
                <div>
                  <p className="font-mono text-[11px] uppercase tracking-wide text-ivory/70">{t("Instruments sélectionnés")}</p>
                  <p className="font-display text-lg font-semibold">
                    {nombreInstruments}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[11px] uppercase tracking-wide text-ivory/70">{t("Montant total(Ecolage + droit d'inscription)")}</p>
                  <p className="font-display text-lg font-semibold">
                    {formatAriary(montantTotal)}
                  </p>
                </div>
              </div>

              <button
                type="submit"
                disabled={nombreInstruments === 0}
                className="w-full rounded-full bg-coral py-3.5 font-body text-sm font-semibold text-ivory shadow-md shadow-coral/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-coral-dark disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0"
              >
                {nombreInstruments === 0
                  ? t("Sélectionne au moins un instrument")
                  : t("Confirmer mon inscription")}
              </button>
            </form>
          )}
        </AnimatedSection>
      </div>
    </section>
  );
}

export default function Inscription() {
  const niveaux = useLevel();
  const instruments = useInstrument();

  return (
    <DataGate
      sources={[
        {
          label: "Chargement des niveaux",
          loading: niveaux.loading,
          error: niveaux.error,
          retry: niveaux.fecthLevels,
        },
        {
          label: "Chargement des instruments",
          loading: instruments.loading,
          error: instruments.error,
          retry: instruments.fecthInstruments,
        },
      ]}
    >
      <InscriptionContent />
    </DataGate>
  );
}
