import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  HiOutlineClock,
  HiOutlineArrowRight,
  HiOutlineCheckCircle,
  HiOutlineDevicePhoneMobile,
  HiOutlineCreditCard,
  HiOutlineBanknotes,
  HiOutlineExclamationCircle,
  HiOutlineMusicalNote,
  HiOutlineShieldCheck,
} from "../../lib/icons";
import AnimatedSection from "../../components/AnimatedSection";
import { NIVEAUX_PARCOURS, MODES_PAIEMENT } from "../../lib/mockFormationData";
import { useLevel } from "../../app/hooks/useLevel";
import { formatAriary } from "../../lib/mockStudentData";
import { storePaiement } from "../../app/api/paiementApi";
import { useLang } from "../../app/hooks/useLang";
import { ActionFeedback, DataGate } from "../../components/AsyncState";
import useAsyncAction from "../../app/hooks/useAsyncAction";

// Cette page n'est accessible qu'après une inscription : elle attend `niveau`
// (obligatoire) et éventuellement `instruments` dans l'URL, transmis par
// home/Inscription.jsx juste après la validation du formulaire d'inscription
// (ex. redirection vers /paiement?niveau=avance&instruments=valiha,kabosy).
function PaiementPublicContent() {
  const { t } = useLang();
  const [searchParams] = useSearchParams();
  const niveauName = searchParams.get("niveau");
  const instrumentsParam = searchParams.get("instruments");
  console.log("instrumentsParam : ", instrumentsParam);
  const inscriptionId = searchParams.get("inscriptionId");
  const instruments = instrumentsParam ? instrumentsParam.split(",") : [];
  console.log("instruments : ", instruments);

  const [nombreMois, setNombreMois] = useState(1);
  const [modePaiement, setModePaiement] = useState(null);
  // Envoi du paiement (spinner plein écran + erreur avec « Réessayer »)
  const action = useAsyncAction();
  const enCours = action.pending;
  const [termine, setTermine] = useState(false);
  const [erreur, setErreur] = useState("");
  const [numeroCarte, setNumeroCarte] = useState("");
  const [expirationCarte, setExpirationCarte] = useState("");
  const [cvvCarte, setCvvCarte] = useState("");

  const [niveau, setNiveau] = useState([]);

  const { levels } = useLevel();

  console.log("levels : ", levels);

  useEffect(() => {
    if (levels && levels.length > 0) {
      const found =
        // filter retourne un tableau
        // levels.filter((level) => level.name === niveauName) || levels[0];

        // find retouren un objet
        levels.find((level) => level.name === niveauName) || levels[0];
      setNiveau(found);
    }
  }, [levels, niveauName]);

  const montantTotalInstrument = niveau.prix_mensuel * instruments.length;
  const sousTotal = nombreMois * montantTotalInstrument;
  const total = sousTotal + parseFloat(niveau.droit_inscription);

  const moisValide = Number.isInteger(nombreMois) && nombreMois >= 1;

  const modesMobileMoney = MODES_PAIEMENT.filter(
    (m) => m.groupe === "mobile_money",
  );
  const modeCarte = MODES_PAIEMENT.find((m) => m.groupe === "carte");
  const paiementParCarte = modePaiement === modeCarte?.id;

  function handleNumeroCarteChange(e) {
    const chiffres = e.target.value.replace(/\D/g, "").slice(0, 19);
    setNumeroCarte(chiffres.replace(/(.{4})/g, "$1 ").trim());
  }

  function handleExpirationChange(e) {
    const chiffres = e.target.value.replace(/\D/g, "").slice(0, 4);
    setExpirationCarte(
      chiffres.length > 2
        ? `${chiffres.slice(0, 2)}/${chiffres.slice(2)}`
        : chiffres,
    );
  }

  function handleCvvChange(e) {
    setCvvCarte(e.target.value.replace(/\D/g, "").slice(0, 4));
  }

  const carteValide =
    !paiementParCarte ||
    (numeroCarte.replace(/\s/g, "").length >= 13 &&
      /^\d{2}\/\d{2}$/.test(expirationCarte) &&
      cvvCarte.length >= 3);

  const handleSubmit = async () => {
    console.log("modePaiement : ", modePaiement);

    if (!moisValide || !modePaiement || !carteValide) {
      setErreur(
        !moisValide || !modePaiement
          ? "Choisis un nombre de mois valide (entre 1 et " +
              niveau.duree +
              ") et un mode de paiement."
          : t("Vérifie les informations de ta carte bancaire (numéro, expiration, CVV)."),
      );
      return;
    }

    setErreur("");

    // « Terminé » n'est affiché que si l'API a bien répondu : en cas d'échec,
    // un bandeau d'erreur avec « Réessayer » apparaît.
    return action.run("Envoi du paiement", async () => {
      const data = {
        nombre_mois: nombreMois,
        montant: total,
        mode_paiement: modePaiement,
        description: t("Premier paiement"),
        ...(paiementParCarte && {
          numero_carte: numeroCarte.replace(/\s/g, ""),
          expiration_carte: expirationCarte,
          cvv_carte: cvvCarte,
        }),
      };

      const response = await storePaiement(inscriptionId, data);
      console.log("Paiement effectué avec succès : ", response.data);
      setTermine(true);
    }, { errorMessage: t("Une erreur est survenue lors du paiement") });
  };

  // Garde-fou : pas de niveau valide/ouvert dans l'URL → pas de paiement possible.
  if (!niveau) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <HiOutlineExclamationCircle className="mx-auto text-brick" size={36} />
        <p className="mt-3 font-body text-sm text-ink-soft">
          {t("Le niveau « {{name}} » n'est pas ouvert à l'inscription directe.", { name: niveau.name })}
        </p>
        <Link
          to="/formation"
          className="mt-4 inline-flex items-center gap-1.5 font-body text-sm font-semibold text-coral-dark hover:text-brick"
        >{t("Voir les niveaux disponibles")}{" "}<HiOutlineArrowRight size={14} />
        </Link>
      </div>
    );
  }

  if (termine) {
    return (
      <div className="mx-auto max-w-lg space-y-4 px-4 py-16 text-center">
        <HiOutlineCheckCircle className="mx-auto text-coral-dark" size={44} />
        <h2 className="font-display text-2xl font-semibold text-ink">{t("Paiement enregistré")}</h2>
        <p className="font-body text-sm text-ink-soft">{t("Ton inscription au niveau")}{" "}<span className="font-semibold text-ink">{niveau.name}</span>{" "}{t("est confirmée pour {{nombreMois}} mois. Tu pourras régler le reste depuis ton espace élève.", { nombreMois })}</p>
        <Link
          to="/eleve/formation"
          className="group inline-flex items-center gap-1.5 rounded-full bg-coral px-5 py-2.5 font-body text-sm font-semibold text-ivory transition-colors duration-300 hover:bg-brick"
        >{t("Accéder à mon espace élève")}<HiOutlineArrowRight
            size={14}
            className="transition-transform duration-300 group-hover:translate-x-1"
          />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-10 px-4 py-12 sm:px-6">
      <ActionFeedback action={action} />
      <input
        type="hidden"
        name="description"
        value="Premier paiement"
        readOnly
      />
      <AnimatedSection className="text-center">
        <p className="font-body text-xs font-medium text-coral-dark">{t("Dernière étape")}</p>
        <h1 className="mt-2 font-display text-3xl font-semibold text-ink sm:text-4xl">{t("Finalise ton inscription")}</h1>
        <p className="mx-auto mt-3 max-w-xl font-body text-sm text-ink-soft">{t("Choisis combien de mois régler aujourd'hui pour le niveau")}{" "}<span className="font-semibold text-ink">{niveau.name}</span>{t(", le reste se gère ensuite depuis ton espace élève.")}</p>
      </AnimatedSection>

      <div className="grid gap-6 lg:grid-cols-[1fr_380px] lg:items-start lg:gap-8">
        {/* Colonne gauche : formulaire */}
        <div className="space-y-6">
          {/* Inscription réalisée */}
          <AnimatedSection className="rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10 p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h3 className="font-display text-base font-semibold text-ink">{t("Ton inscription")}</h3>
                <p className="mt-1 font-body text-sm text-ink-soft">{t("Niveau {{name}} · {{v0}} / mois", { name: niveau.name, v0: formatAriary(niveau.prix_mensuel) })}</p>
              </div>
              <span className="rounded-full bg-coral/10 px-3 py-1 font-body text-xs font-semibold text-coral-dark">
                {niveau.name}
              </span>
            </div>
            <div className="border-t border-ivory-dark pt-4 mt-4">
              <p className="mt-1 font-body text-sm text-ink-soft">{t("Instruments :")}{" "}{instruments.map((instrument) => (
                  <span
                    key={instrument}
                    className="rounded-full bg-ivory px-2.5 py-0.5 font-body text-xs text-ink-soft"
                  >
                    {instrument}
                  </span>
                ))}
              </p>
              <p className="mt-1 font-body text-sm text-ink-soft">{t("Montant total par mois : {{v0}} / mois", { v0: formatAriary(montantTotalInstrument) })}</p>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-4 border-t border-ivory-dark pt-4">
              <span className="flex items-center gap-1.5 font-body text-xs text-ink-soft">
                <HiOutlineClock size={14} />{" "}{t("Durée du niveau : {{duree}}", { duree: niveau.duree })}</span>
              {instruments.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5">
                  <HiOutlineMusicalNote size={14} className="text-ink-soft" />
                  {instruments.map((instrument) => (
                    <span
                      key={instrument}
                      className="rounded-full bg-ivory px-2.5 py-0.5 font-body text-xs text-ink-soft"
                    >
                      {instrument}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </AnimatedSection>

          {/* Mensualité */}
          <AnimatedSection
            delay={80}
            className="rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10 p-6"
          >
            <h3 className="font-display text-base font-semibold text-ink">{t("Mensualité")}</h3>
            <p className="mt-1 font-body text-sm text-ink-soft">{t("Montant mensuel de ce niveau :")}{" "}<span className="font-semibold text-ink">{t("{{v0}} / mois", { v0: formatAriary(montantTotalInstrument) })}</span>
            </p>

            <label
              className="mt-5 block font-body text-xs font-medium text-ink-soft"
              htmlFor="nombreMois"
            >{t("Nombre de mois à payer maintenant (max {{duree}})", { duree: niveau.duree })}</label>
            <div className="mt-2 flex items-center gap-3">
              <input
                id="nombreMois"
                type="number"
                min={1}
                max={niveau.duree}
                value={nombreMois}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  const borne = Number.isNaN(val)
                    ? 1
                    : Math.min(Math.max(val, 1), niveau.duree.split(" ")[0]);
                  setNombreMois(borne);
                }}
                className="w-28 rounded-lg border border-ivory-dark  px-3 py-2.5 font-body text-sm text-ink focus:border-coral focus:outline-none"
              />
              <span className="font-body text-sm text-ink-soft">
                {nombreMois > 1 ? "mois" : "mois"} · {formatAriary(sousTotal)}
              </span>
            </div>
          </AnimatedSection>

          {/* Mode de paiement */}
          <AnimatedSection
            delay={160}
            className="rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10 p-6"
          >
            <h3 className="font-display text-base font-semibold text-ink">{t("Mode de paiement")}</h3>

            <p className="mt-4 flex items-center gap-1.5 font-body text-xs font-medium text-ink-soft">
              <HiOutlineDevicePhoneMobile size={14} />{" "}{t("Mobile Money")}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {modesMobileMoney.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setModePaiement(m.id)}
                  className={`rounded-full border px-4 py-2 font-body text-sm font-medium transition-colors duration-200 ${
                    modePaiement === m.id
                      ? "border-coral bg-coral text-ivory"
                      : "border-ivory-dark text-ink-soft hover:border-coral hover:text-coral-dark"
                  }`}
                >
                  {m.nom}
                </button>
              ))}
            </div>

            <p className="mt-5 flex items-center gap-1.5 font-body text-xs font-medium text-ink-soft">
              <HiOutlineCreditCard size={14} />{" "}{t("Carte bancaire")}</p>
            <div className="mt-2">
              <button
                type="button"
                onClick={() => setModePaiement(modeCarte.id)}
                className={`rounded-full border px-4 py-2 font-body text-sm font-medium transition-colors duration-200 ${
                  modePaiement === modeCarte.id
                    ? "border-coral bg-coral text-ivory"
                    : "border-ivory-dark text-ink-soft hover:border-coral hover:text-coral-dark"
                }`}
              >
                {modeCarte.nom}
              </button>
            </div>

            {paiementParCarte && (
              <div className="mt-4 grid gap-3 rounded-xl border border-ivory-dark bg-ivory-dark/20 p-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label
                    className="block font-body text-xs font-medium text-ink-soft"
                    htmlFor="numeroCarte"
                  >{t("Numéro de carte")}</label>
                  <input
                    id="numeroCarte"
                    type="text"
                    inputMode="numeric"
                    autoComplete="cc-number"
                    placeholder="1234 5678 9012 3456"
                    value={numeroCarte}
                    onChange={handleNumeroCarteChange}
                    className="mt-1.5 w-full rounded-lg border border-ivory-dark bg-white px-3 py-2.5 font-body text-sm text-ink focus:border-coral focus:outline-none"
                  />
                </div>
                <div>
                  <label
                    className="block font-body text-xs font-medium text-ink-soft"
                    htmlFor="expirationCarte"
                  >{t("Expiration (MM/AA)")}</label>
                  <input
                    id="expirationCarte"
                    type="text"
                    inputMode="numeric"
                    autoComplete="cc-exp"
                    placeholder="MM/AA"
                    value={expirationCarte}
                    onChange={handleExpirationChange}
                    className="mt-1.5 w-full rounded-lg border border-ivory-dark bg-white px-3 py-2.5 font-body text-sm text-ink focus:border-coral focus:outline-none"
                  />
                </div>
                <div>
                  <label
                    className="block font-body text-xs font-medium text-ink-soft"
                    htmlFor="cvvCarte"
                  >{t("CVV")}</label>
                  <input
                    id="cvvCarte"
                    type="password"
                    inputMode="numeric"
                    autoComplete="cc-csc"
                    placeholder="•••"
                    value={cvvCarte}
                    onChange={handleCvvChange}
                    className="mt-1.5 w-full rounded-lg border border-ivory-dark bg-white px-3 py-2.5 font-body text-sm text-ink focus:border-coral focus:outline-none"
                  />
                </div>
              </div>
            )}

            <p className="mt-5 flex items-center gap-1.5 border-t border-ivory-dark pt-4 font-body text-xs text-ink-soft">
              <HiOutlineShieldCheck size={14} className="text-coral-dark" />{t("Paiement sécurisé, traité une seule fois par mensualité choisie.")}</p>
          </AnimatedSection>
        </div>

        {/* Colonne droite : récapitulatif, fixé à côté du formulaire */}
        <AnimatedSection
          delay={120}
          className="rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10 p-6 lg:sticky lg:top-24"
        >
          <h3 className="flex items-center gap-1.5 font-display text-base font-semibold text-ink">
            <HiOutlineBanknotes size={18} />{" "}{t("Récapitulatif")}</h3>

          <dl className="mt-4 space-y-3 font-body text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-ink-soft">{t(instruments.length > 1 ? "{{nombreMois}} mois × {{v0}} × {{length}} instruments" : "{{nombreMois}} mois × {{v0}} × {{length}} instrument", { nombreMois, v0: formatAriary(niveau.prix_mensuel), length: instruments.length })}
              </dt>
              <dd className="text-ink">{formatAriary(sousTotal)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-ink-soft">{t("Droit d'inscription au niveau")}</dt>
              <dd className="text-ink">
                {formatAriary(niveau.droit_inscription)}
              </dd>
            </div>
            <div className="flex items-center justify-between border-t border-ivory-dark pt-3 text-base font-semibold">
              <dt className="text-ink">{t("Total à payer")}</dt>
              <dd className="text-coral-dark">{formatAriary(total)}</dd>
            </div>
          </dl>

          <p className="mt-4 font-body text-xs text-ink-soft">{t("Mode choisi :")}{" "}<span className="font-medium text-ink">
              {MODES_PAIEMENT.find((m) => m.id === modePaiement)?.nom ||
                t("aucun pour l'instant")}
            </span>
          </p>

          {erreur && (
            <p className="mt-4 rounded-lg bg-brick/10 px-3 py-2 font-body text-xs font-medium text-brick">
              {erreur}
            </p>
          )}

          <button
            type="button"
            onClick={handleSubmit}
            disabled={enCours}
            className="group mt-5 inline-flex w-full items-center justify-center gap-1.5 rounded-full bg-coral px-5 py-3 font-body text-sm font-semibold text-ivory transition-colors duration-300 hover:bg-brick disabled:opacity-60"
          >
            {enCours ? t("Traitement…") : t("Confirmer le paiement")}
            {!enCours && (
              <HiOutlineArrowRight
                size={14}
                className="transition-transform duration-300 group-hover:translate-x-1"
              />
            )}
          </button>
        </AnimatedSection>
      </div>
    </div>
  );
}

export default function PaiementPublic() {
  const niveaux = useLevel();

  return (
    <DataGate
      sources={[
        {
          label: "Chargement des niveaux",
          loading: niveaux.loading,
          error: niveaux.error,
          retry: niveaux.fecthLevels,
        },
      ]}
    >
      <PaiementPublicContent />
    </DataGate>
  );
}
