import { Link } from "react-router-dom";
import { HiOutlineArrowRight, HiOutlinePlay, HiStar } from "react-icons/hi";
import {
  HiOutlineDevicePhoneMobile,
  HiOutlineAcademicCap,
  HiOutlineChatBubbleLeftRight,
} from "react-icons/hi2";
import AnimatedSection from "../../components/AnimatedSection";
import ValihaMotif from "../../components/ValihaMotif";
import {
  instruments,
  courses,
  teachers,
  testimonials,
} from "../../lib/mockHomeData";
import { useUser } from "../../app/hooks/useUser";
import { useInstrument } from "../../app/hooks/useInstrument";
import { useLang } from "../../app/hooks/useLang";
import { DataGate } from "../../components/AsyncState";

const STEPS = [
  {
    icon: HiOutlineAcademicCap,
    titre: "Choisissez votre instrument",
    texte:
      "Valiha, kabosy, piano, guitare, chant ou batterie : trouvez le cours adapté à votre niveau.",
  },
  {
    icon: HiOutlineDevicePhoneMobile,
    titre: "Apprenez à votre rythme",
    texte:
      "Vidéos, PDF et audio accessibles à tout moment, sur mobile comme sur ordinateur.",
  },
  {
    icon: HiOutlineChatBubbleLeftRight,
    titre: "Échangez avec un vrai professeur",
    texte:
      "Posez vos questions, recevez des corrections et suivez votre progression pas à pas.",
  },
];

// Maps statiques : Tailwind doit voir les noms de classes complets en clair
// dans le code source pour les générer (les gabarits dynamiques `bg-${x}` sont ignorés).
const AVATAR_BG = { coral: "bg-coral", amber: "bg-amber", brick: "bg-brick" };
const CARD_BG = {
  coral: "bg-coral/90",
  amber: "bg-amber/90",
  brick: "bg-brick/90",
};

function formatAriary(n) {
  return new Intl.NumberFormat("fr-MG").format(n) + " Ar";
}

function HomeContent() {
  const { t: tl } = useLang();
  const {instruments} = useInstrument();
  const {userList} = useUser();
  const prof = userList.filter((u) => u.role_id === 3);
  
  return (
    <>
      {/* ---------- HERO ---------- */}
      <section className="relative overflow-hidden px-5 pb-20 pt-16 sm:px-8 sm:pt-24">
        <div
          className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-amber-light/40 blur-3xl"
          aria-hidden="true"
        />
        <div
          className="absolute -left-32 top-40 h-72 w-72 rounded-full bg-coral-light/30 blur-3xl"
          aria-hidden="true"
        />

        <div className="relative mx-auto grid max-w-7xl items-center gap-14 lg:grid-cols-2">
          <AnimatedSection>
            <span className="inline-flex items-center gap-2 rounded-full bg-brick/5 px-4 py-1.5 font-mono text-xs uppercase tracking-widest text-brick">{tl("Fa mbola misy ny mozika malagasy")}</span>
            <h1 className="mt-6 font-display text-5xl font-semibold leading-[1.05] tracking-tight text-ink sm:text-6xl">{tl("Apprenez la musique,")}<span className="relative inline-block px-1 text-coral">{" "}{tl("selon votre rythme")}</span>
            </h1>
            <p className="mt-6 max-w-lg font-body text-lg leading-relaxed text-ink-soft">{tl("Kalon'ny réunit de vrais professeurs et un parcours guidé pour apprendre le piano, la guitare, le saxophone ou la batterie — où que vous soyez à Madagascar.")}</p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <Link
                to="/formation"
                className="group inline-flex items-center gap-2 rounded-full bg-coral px-7 py-3.5 font-body text-sm font-semibold text-ivory shadow-lg shadow-coral/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-coral-dark"
              >{tl("Explorer les formations")}<HiOutlineArrowRight className="transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
              
            </div>

            <dl className="mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-ivory-dark pt-6">
              {[
                ["6", tl("instruments")],
                ["1 000+", tl("élèves actifs")],
                ["4.8/5", tl("note moyenne")],
              ].map(([n, l]) => (
                <div key={l}>
                  <dt className="font-display text-2xl font-semibold text-ink">
                    {n}
                  </dt>
                  <dd className="font-mono text-xs uppercase tracking-wide text-ink-soft">
                    {l}
                  </dd>
                </div>
              ))}
            </dl>
          </AnimatedSection>

          <AnimatedSection delay={150} className="relative">
            <div className="relative overflow-hidden rounded-4xl bg-linear-to-br from-brick via-coral to-amber p-1 shadow-2xl shadow-brick/20">
              <div className="rounded-[1.85rem] bg-ink/90 p-8 sm:p-10">
                <ValihaMotif count={26} tone="amber" className="h-24" />
                <p className="mt-6 font-display text-xl italic leading-snug text-ivory">{tl("« Le valiha, ce n'est pas qu'un instrument. C'est une voix qu'on transmet. »")}</p>
                <p className="mt-3 font-mono text-xs uppercase tracking-widest text-amber-light">{tl("— Njaka Rakotondrabe, professeur")}</p>
              </div>
            </div>
            <div className="absolute -bottom-6 -left-6 flex items-center gap-3 rounded-2xl bg-white/95 px-5 py-4 shadow-xl backdrop-blur">
              <div className="flex -space-x-2">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="h-8 w-8 rounded-full border-2 border-white bg-linear-to-br from-coral to-amber"
                  />
                ))}
              </div>
              <div>
                <p className="font-display text-sm font-semibold text-ink">{tl("+1 000 élèves")}</p>
                <p className="font-mono text-[10px] uppercase tracking-wide text-ink-soft">{tl("nous font confiance")}</p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* ---------- INSTRUMENTS ---------- */}
      <section className="px-5 py-20 sm:px-8">
        <div className="mx-auto max-w-7xl">
          <AnimatedSection className="max-w-xl">
            <span className="font-mono text-xs uppercase tracking-widest text-coral-dark">{tl("Nos instruments")}</span>
            <h2 className="mt-3 font-display text-3xl font-semibold text-ink sm:text-4xl">{tl("Six voies pour faire chanter la musique malgache")}</h2>
          </AnimatedSection>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {instruments.slice(0, 6).map((instr, i) => (
              <AnimatedSection
                key={instr.id}
                delay={i * 80}
                as={Link}
                className="group block rounded-2xl border border-ivory-dark bg-white/60 dark:bg-white/10 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-coral/40 hover:shadow-xl hover:shadow-coral/10"
              >
                {/* <span className="text-3xl">{instr.emoji}</span> */}
                <h3 className="mt-4 font-display text-lg font-semibold text-ink group-hover:text-coral-dark">
                  {instr.name}
                </h3>
                <p className="mt-2 font-body text-sm leading-relaxed text-ink-soft">
                  {instr.description ? instr.description : tl("Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laudantium, voluptate.")}
                </p>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- COMMENT ÇA MARCHE ---------- */}
      <section className="bg-ivory-dark/50 px-5 py-20 sm:px-8">
        <div className="mx-auto max-w-7xl">
          <AnimatedSection className="max-w-xl">
            <span className="font-mono text-xs uppercase tracking-widest text-coral-dark">{tl("Le parcours")}</span>
            <h2 className="mt-3 font-display text-3xl font-semibold text-ink sm:text-4xl">{tl("Comment ça marche")}</h2>
          </AnimatedSection>

          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {STEPS.map((step, i) => (
              <AnimatedSection
                key={step.titre}
                delay={i * 120}
                className="relative"
              >
                <span className="font-mono text-5xl font-light text-coral/20">
                  0{i + 1}
                </span>
                <div className="mt-3 grid h-12 w-12 place-items-center rounded-xl bg-coral/10 text-coral-dark">
                  <step.icon size={22} />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold text-ink">
                  {step.titre}
                </h3>
                <p className="mt-2 font-body text-sm leading-relaxed text-ink-soft">
                  {tl(step.texte)}
                </p>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- PROFESSEURS ---------- */}
      <section className="bg-ink px-5 py-20 sm:px-8">
        <div className="mx-auto max-w-7xl">
          <AnimatedSection className="max-w-xl">
            <span className="font-mono text-xs uppercase tracking-widest text-amber-light">{tl("Nos professeurs")}</span>
            <h2 className="mt-3 font-display text-3xl font-semibold text-ivory sm:text-4xl">{tl("Appris par des passionnés, transmis avec exigence")}</h2>
          </AnimatedSection>

          <div className="mt-12 flex gap-5 overflow-x-auto pb-4 scrollbar-none [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
            {prof.slice(0, 5).map((t, i) => (
              <AnimatedSection
                key={t.id}
                delay={i * 80}
                className="w-64 shrink-0 rounded-2xl bg-ivory/6 p-6 backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:bg-ivory/10"
              >
                <div
                  className={`h-14 w-14 rounded-full grid place-items-center font-display text-lg font-semibold text-ivory bg-amber`}
                >
                  {`${t.firstname?.[0] || ""}${t.name?.[0] || ""}`.toUpperCase()}
                </div>
                <h3 className="mt-4 font-display text-base font-semibold text-ivory">
                  <Link
                    to={`/professeurs/${t.id}`}
                    className="transition-colors hover:text-amber-light"
                  >
                    {t?.firstname} {t?.name}
                  </Link>
                </h3>
                <p className="mt-3 font-body text-sm leading-relaxed text-ivory/60">
                  {t?.bio ? t?.bio : tl("Lorem ipsum dolor, sit amet consectetur adipisicing elit. Laudantium, voluptate.")}
                </p>
                {/* <p className="mt-4 flex items-center gap-1 font-body text-sm text-ivory/70">
                  <HiStar className="text-amber" size={14} /> {t.note} ·{" "}
                  {t?.eleves} élèves
                </p> */}
                <p className="mt-4 flex items-center gap-1 font-body text-sm text-ivory/70">
                  <HiStar className="text-amber" size={14} />{" "}{tl("10 · 15 élèves")}</p>
                <Link
                  to={`/professeurs/${t.id}`}
                  className="mt-4 inline-flex items-center gap-1.5 font-body text-sm font-semibold text-amber-light transition-colors hover:text-ivory"
                >{tl("Voir le portfolio")}{" "}<HiOutlineArrowRight size={14} />
                </Link>
              </AnimatedSection>
            ))}
          </div>
          <Link
            to="/professeurs"
            className="mt-8 inline-flex items-center gap-1.5 font-body text-sm font-semibold text-amber-light hover:text-ivory"
          >{tl("Voir tous les professeurs")}{" "}<HiOutlineArrowRight size={15} />
          </Link>
        </div>
      </section>

      {/* ---------- TÉMOIGNAGES ---------- */}
      <section className="px-5 py-20 sm:px-8">
        <div className="mx-auto max-w-7xl">
          <AnimatedSection className="max-w-xl">
            <span className="font-mono text-xs uppercase tracking-widest text-coral-dark">{tl("Témoignages")}</span>
            <h2 className="mt-3 font-display text-3xl font-semibold text-ink sm:text-4xl">{tl("Ce que disent nos élèves")}</h2>
          </AnimatedSection>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <AnimatedSection
                key={t.id}
                delay={i * 100}
                className="rounded-2xl border border-ivory-dark bg-white/60 dark:bg-white/10 p-6"
              >
                <div className="flex gap-0.5 text-amber">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <HiStar key={s} size={15} />
                  ))}
                </div>
                <p className="mt-4 font-body text-sm leading-relaxed text-ink-soft">
                  « {tl(t.texte)} »
                </p>
                <p className="mt-5 font-display text-sm font-semibold text-ink">
                  {t.nom}
                </p>
                <p className="font-mono text-[11px] uppercase tracking-wide text-coral-dark">
                  {tl(t.role)}
                </p>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- CTA FINAL ---------- */}
      <section className="px-5 pb-24 sm:px-8">
        <AnimatedSection className="mx-auto max-w-5xl overflow-hidden rounded-4xl bg-linear-to-br from-brick via-coral-dark to-coral px-8 py-16 text-center sm:px-16">
          <h2 className="font-display text-3xl font-semibold text-ivory sm:text-4xl">{tl("Prêt à faire vos premiers accords ?")}</h2>
          <p className="mx-auto mt-4 max-w-md font-body text-ivory/80">{tl("Rejoignez plus de 1 000 élèves malgaches qui apprennent la musique à leur rythme, avec de vrais professeurs.")}</p>
          <Link
            to="/inscriptionCompte"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-ivory px-8 py-3.5 font-body text-sm font-semibold text-brick shadow-lg transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl"
          >{tl("Créer mon compte gratuit")}{" "}<HiOutlineArrowRight />
          </Link>
        </AnimatedSection>
      </section>
    </>
  );
}

export default function Home() {
  const instruments = useInstrument();
  const users = useUser();

  return (
    <DataGate
      sources={[
        {
          label: "Chargement des instruments",
          loading: instruments.loading,
          error: instruments.error,
          retry: instruments.fecthInstruments,
        },
        {
          label: "Chargement des professeurs",
          loading: users.loading,
          error: users.error,
          retry: users.fetchUserList,
        },
      ]}
    >
      <HomeContent />
    </DataGate>
  );
}
