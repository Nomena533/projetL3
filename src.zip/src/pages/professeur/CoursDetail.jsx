import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams, useLocation } from "react-router-dom";
import { HiPlus } from "react-icons/hi";
import {
  HiOutlineChevronLeft,
  HiOutlineEye,
  HiOutlinePencilSquare,
  HiOutlineTrash,
  HiOutlineDocumentText,
  HiOutlineCheckCircle,
  HiOutlineXMark,
  HiOutlinePhoto,
} from "react-icons/hi2";
import AnimatedSection from "../../components/AnimatedSection";
import Modal from "../../components/Modal";
import Pill from "../../components/Pill";
import FilterBar from "../../components/FilterBar";
// ⚠️ getCourDetail / deleteLesson sont attendus dans courApi.js — voir la note
// en bas de fichier si ces fonctions n'existent pas encore de ton côté.
import { getCourDetail } from "../../app/api/courApi";
import { deleteLesson } from "../../app/api/lessonApi";
import { BASE_URL } from "../../app/api/api";
import { capitalize } from "../../lib/formatFunction";
import { getRessourceByLecon } from "../../app/api/ressourceApi";
import { useLang } from "../../app/hooks/useLang";
import { ActionFeedback, DataGate } from "../../components/AsyncState";
import useAsyncAction from "../../app/hooks/useAsyncAction";

export default function ProfCoursDetail() {
  const { t } = useLang();
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const [cours, setCoursDetail] = useState(null);
  // Chargement du cours (plein écran + « Réessayer »), de ses ressources, et suppression d'une leçon
  const load = useAsyncAction({ initialPending: true, initialLabel: "Chargement du cours" });
  const loadRes = useAsyncAction();
  const action = useAsyncAction();
  const [toDelete, setToDelete] = useState(null);
  const [alert, setAlert] = useState(location.state?.success || null);

  const [resourceCounts, setResourceCounts] = useState({});

  const [search, setSearch] = useState("");

  const fetchCourDetail = () =>
    load.run("Chargement du cours", async () => {
      const response = await getCourDetail(id);
      setCoursDetail(response.data);
      console.log("Détails du cour sélectionnés avec succès");
    }, { errorMessage: t("Impossible de charger ce cours.") });

  useEffect(() => {
    fetchCourDetail();
  }, [id]);


  // A EXPLIQUER
  useEffect(() => {
    if(!cours) return;

    const fetchResources = () =>
      loadRes.run("Chargement des ressources des leçons", async () => {
        const results = await Promise.all(
          cours.lesson.map(async (lesson) => {
            const response = await getRessourceByLecon(lesson.id);

            return {
              id : lesson.id,
              count : response.data.length
            };
          })
        );

        const counts = {};

        results.forEach((result) => {
          counts[result.id] = result.count;
        });

        setResourceCounts(counts);
      });

    fetchResources();
  }, [cours]);

  useEffect(() => {
    if (location.state)
      navigate(location.pathname, { replace: true, state: {} });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!alert) return;
    const timer = setTimeout(() => setAlert(null), 5000);
    return () => clearTimeout(timer);
  }, [alert]);

  const handleDeleteLecon = (leconId) => {
    console.log("leconId", leconId);
    // On ferme la fenêtre de confirmation : l'erreur éventuelle s'affiche sur la page.
    setToDelete(null);

    return action.run("Suppression de la leçon", async () => {
      await deleteLesson(leconId);

      setCoursDetail((c) => ({
        ...c,
        lesson: c.lesson.filter((l) => l.id !== leconId),
      }));

      setAlert(t("La leçon a été supprimé avec succès !"));
    }, { errorMessage: t("Une erreur est survenue lors de la suppression de la leçon.") });
  };

  // A EXPLIQUER
  const filteredLecons = useMemo(() => {
    if (!cours?.lesson) return [];
    if (!search) return cours.lesson;
    return cours.lesson.filter((l) =>
      (l.titre || "").toLowerCase().includes(search.toLowerCase()),
    );
  }, [cours, search]);

  if (load.pending || load.error) {
    return <ActionFeedback action={load} variant="fetch" />;
  }

  if (!cours) {
    return (
      <div className="space-y-4">
        <p className="font-body text-sm text-brick">
          {t("Cours introuvable.")}
        </p>
        <Link
          to="/professeur/mescours"
          className="font-body text-sm font-semibold text-coral-dark hover:text-brick"
        >{t("← Retour à mes cours")}</Link>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6">
      <ActionFeedback action={action} />
      <ActionFeedback action={loadRes} />
      <button
        onClick={() => navigate("/professeur/mescours")}
        className="inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-wide text-ink-soft transition-colors hover:text-coral-dark"
      >
        <HiOutlineChevronLeft size={13} />{" "}{t("Retour à mes cours")}</button>

      {alert && (
        <div className="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 font-body text-sm text-emerald-700">
          <HiOutlineCheckCircle size={18} className="mt-0.5 shrink-0" />
          <p className="flex-1">{alert}</p>
          <button
            onClick={() => setAlert(null)}
            aria-label={t("Fermer")}
            className="shrink-0 opacity-70 hover:opacity-100"
          >
            <HiOutlineXMark size={16} />
          </button>
        </div>
      )}

      {/* En-tête du cours */}
      <AnimatedSection className="overflow-hidden rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10">
        <div className="grid gap-0 lg:grid-cols-[360px_1fr]">
          <div className="flex aspect-video w-full items-center justify-center bg-ivory-dark/40 lg:aspect-auto lg:h-full">
            {cours.cour.image ? (
              <img
                src={`${BASE_URL}/storage/${cours.cour.image}`}
                alt={cours.cour.titre}
                className="h-full w-full object-cover"
              />
            ) : (
              <HiOutlinePhoto size={28} className="text-ink-soft" />
            )}
          </div>
          <div className="space-y-4 p-6 sm:p-7">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs uppercase tracking-widest text-coral-dark">
                    {cours.cour.instrument?.name}
                  </span>
                  {cours.cour.statut && <Pill>{t(cours.cour.statut)}</Pill>}
                </div>
                <h2 className="mt-1 font-display text-2xl font-semibold text-ink sm:text-3xl">
                  {capitalize(cours.cour.titre)}
                </h2>
              </div>
              <Link
                to={`/professeur/cours/${id}`}
                className="inline-flex items-center gap-1.5 rounded-full border border-ivory-dark px-4 py-2 font-body text-xs font-semibold text-ink transition-colors hover:border-coral/40"
              >
                <HiOutlinePencilSquare size={14} />{" "}{t("Modifier")}</Link>
            </div>

            {cours.cour.description && (
              <p className="font-body text-sm leading-relaxed text-ink-soft">
                {capitalize(cours.cour.description)}
              </p>
            )}

            <div className="flex flex-wrap gap-x-6 gap-y-2 font-body text-sm text-ink-soft">
              <span>
                <strong className="text-ink">{t("Durée :")}{" "}</strong>
                {cours.cour.duree || "—"}
              </span>
              <span>
                <strong className="text-ink">{t("Leçons :")}{" "}</strong>
                {cours.lesson?.length ?? 0}
              </span>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Leçons */}
      <AnimatedSection
        delay={80}
        className="rounded-2xl border border-ivory-dark bg-white/70 dark:bg-white/10 p-6 sm:p-7"
      >
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-display text-lg font-semibold text-ink">{t("Leçons")}</h3>
          <Link
            to={`/professeur/cours/${id}/lecons/nouveau`}
            className="flex items-center gap-1.5 font-mono text-xs font-semibold uppercase tracking-wide text-coral-dark transition-colors hover:text-brick"
          >
            <HiPlus size={14} />{" "}{t("Ajouter une leçon")}</Link>
        </div>

        {cours.lesson?.length > 0 && (
          <div className="mb-4">
            <FilterBar
              searchValue={search}
              onSearchChange={setSearch}
              searchPlaceholder={t("Rechercher une leçon…")}
              resultCount={filteredLecons.length}
              totalCount={cours.lesson.length}
              hasActiveFilters={search !== ""}
              onReset={() => setSearch("")}
            />
          </div>
        )}

        {cours.lesson?.length ? (
          filteredLecons.length ? (
            <div className="space-y-3">
              {filteredLecons.map((l) => {
                const index = cours.lesson.findIndex((x) => x.id === l.id);
                // const ressourceCount =
                //   l.ressources_count ?? l.ressources?.length ?? 0;
                return (
                  <div
                    key={l.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ivory-dark p-4 transition-colors duration-300 hover:border-coral/30"
                  >
                    <Link
                      to={`/professeur/cours/${id}/lecons/${l.id}/details`}
                      className="flex min-w-0 flex-1 items-center gap-3"
                    >
                      <span className="shrink-0 font-mono text-xs text-ink-soft">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate font-body text-sm font-semibold text-ink transition-colors hover:text-coral-dark">
                          {capitalize(l.titre) || "_"}
                        </p>
                        {l.description && (
                          <p className="truncate font-body text-xs text-ink-soft">
                            {capitalize(l.description)}
                          </p>
                        )}
                      </div>
                    </Link>
                    <div className="flex shrink-0 items-center gap-3">
                      <span className="flex items-center gap-1.5 rounded-full border border-ivory-dark px-3 py-1 font-body text-xs text-ink-soft">
                        <HiOutlineDocumentText size={13} />{t(resourceCounts[l.id] > 1 ? "{{v0}} ressources" : "{{v0}} ressource", { v0: resourceCounts[l.id] })}
                      </span>
                      {l.duree && (
                        <span className="font-mono text-xs text-ink-soft">
                          {l.duree}
                        </span>
                      )}
                      <Link
                        to={`/professeur/cours/${id}/lecons/${l.id}/details`}
                        className="text-ink-soft transition-colors hover:text-coral-dark"
                        aria-label={t("Voir la leçon")}
                      >
                        <HiOutlineEye size={17} />
                      </Link>
                      <Link
                        to={`/professeur/cours/${id}/lecons/${l.id}`}
                        className="text-ink-soft transition-colors hover:text-coral-dark"
                        aria-label={t("Modifier")}
                      >
                        <HiOutlinePencilSquare size={17} />
                      </Link>
                      <button
                        onClick={() => setToDelete(l)}
                        className="text-ink-soft transition-colors hover:text-brick"
                        aria-label={t("Supprimer la leçon")}
                      >
                        <HiOutlineTrash size={15} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="rounded-xl border border-dashed border-ivory-dark px-5 py-10 text-center font-body text-sm text-ink-soft">{t("Aucune leçon ne correspond à ta recherche.")}</p>
          )
        ) : (
          <p className="rounded-xl border border-dashed border-ivory-dark px-5 py-10 text-center font-body text-sm text-ink-soft">{t("Ce cours n'a pas encore de leçon.")}{" "}<Link
              to={`/professeur/cours/${id}/lecons/nouveau`}
              className="font-semibold text-coral-dark hover:text-brick"
            >{t("Ajoute la première →")}</Link>
          </p>
        )}
      </AnimatedSection>

      <Modal
        open={!!toDelete}
        onClose={() => setToDelete(null)}
        title={t("Supprimer cette leçon ?")}
      >
        <p className="font-body text-sm leading-relaxed text-ink-soft">
          <span className="font-semibold text-ink">« {toDelete?.titre} »</span>{" "}{t("sera définitivement supprimée, ainsi que ses ressources. Cette action est irréversible.")}</p>
        <div className="mt-6 flex gap-3">
          <button
            onClick={() => setToDelete(null)}
            className="flex-1 rounded-full border border-ivory-dark py-2.5 font-body text-sm font-semibold text-ink transition-colors duration-300 hover:bg-ivory-dark/40"
          >{t("Annuler")}</button>
          <button
            onClick={() => {
              handleDeleteLecon(toDelete?.id);
            }}
            className="flex-1 rounded-full bg-brick py-2.5 font-body text-sm font-semibold text-ivory shadow-lg shadow-brick/25 transition-all duration-300 hover:bg-brick-light"
          >{t("Supprimer")}</button>
        </div>
      </Modal>
    </div>
  );
}
