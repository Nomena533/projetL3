import { useState } from "react";
import {
  Link,
  NavLink,
  useLocation,
  useNavigate,
  useSearchParams,
} from "react-router-dom";
import {
  HiOutlineArrowLeft,
  HiOutlineEnvelope,
  HiOutlineLockClosed,
  HiOutlineEye,
  HiOutlineEyeSlash,
  HiOutlineArrowRightOnRectangle,
  HiOutlineUserPlus,
  HiOutlineAcademicCap,
  HiOutlineMusicalNote,
  HiOutlineCheckCircle,
} from "react-icons/hi2";
import { HiStar } from "react-icons/hi";
import AnimatedSection from "../../components/AnimatedSection";
import ValihaMotif from "../../components/ValihaMotif";
import FormField from "../../components/FormField";
import Modal from "../../components/Modal";
import { login } from "../../app/api/authApi";
import { useAuth } from "../../app/hooks/useAuth";
import { useUser } from "../../app/hooks/useUser";
import { LogoBlanc, LogoVert } from "../../components/Logo";
import useTheme from "../../app/hooks/useTheme";
import { useLang } from "../../app/hooks/useLang";
import { ActionFeedback } from "../../components/AsyncState";
import useAsyncAction from "../../app/hooks/useAsyncAction";

export default function Login() {
  const { t } = useLang();
  const {isDark} = useTheme();
  const { setUser } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  console.log("Location : ", location);

  const { fetchUserListInscription } = useUser();
  // Suivi de la connexion (spinner plein écran + erreur avec « Réessayer »)
  const action = useAsyncAction();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  // Affichage d'une modale quand l'élève est déjà inscrit au niveau visé
  const [showAlreadyEnrolledModal, setShowAlreadyEnrolledModal] =
    useState(false);
  const [alreadyEnrolledNiveau, setAlreadyEnrolledNiveau] = useState(null);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    action.run("Connexion en cours", submitLogin, {
      errorMessage: t("Connexion impossible. Vérifiez vos identifiants."),
    });
  };

  const submitLogin = async () => {
    {
      const response = await login(form);

      console.log("Réponse.data : ", response.data);

      // Laravel renvoie le token Sanctum
      // const token = response.data.token;
      const { token, user } = response.data;

      // console.log("user",user);
      // return;

      // Sauvegarde le token pour les prochaines requêtes API
      localStorage.setItem("token", token);

      // const user = response.data.user;

      // Sauvegarde les information de l'user, JSON.stringify transforme l'objet user en text pour pouvoir le stocker
      localStorage.setItem("user", JSON.stringify(user));

      console.log("Connexion réussi : ", response.data);

      setUser(user);

      // listInscription contient les données qui seront juste disponible dans le handleSubmit
      const listInscription = await fetchUserListInscription(user.id);

      // si l'utilisateur était en train d'accéder à une page protégée, on la renvoir vers cette page après connexion
      // state et from sont envoyé en même temps avec la navigation dans components/RoleRoute.jsx
      const from = location.state?.from; // => donne /inscription?niveau=initiation après console.log()

      // "from" n'existe que si l'utilisateur venait d'une redirection (ex: page protégée).
      // Sur une connexion classique il est undefined, donc on protège l'accès avant de le parser.
      let inscrit = false;
      let niveauFromParams = null;

      if (from) {
        const searchParams = new URLSearchParams(from.split("?")[1] || "");
        niveauFromParams = searchParams.get("niveau");

        if (niveauFromParams) {
          const inscription = listInscription.filter(
            (inscription) => inscription.level.name === niveauFromParams,
          );

          inscrit = inscription.length === 1;
        }
      }

      if (inscrit) {
        setAlreadyEnrolledNiveau(niveauFromParams);
        setShowAlreadyEnrolledModal(true);
        return;
      }

      if (from) {
        // replace: true empêche l'user de revenir en arrière qui est la page login
        navigate(from, { replace: true });
        return;
      }

      // Récupération du rôle
      const role = user.role;

      console.log(role);
      // Redirection selon role
      if (role === "eleve") {
        navigate("/eleve", { replace: true });
      } else if (role === "professeur") {
        navigate("/professeur", { replace: true });
      } else {
        navigate("/administrateur", { replace: true });
      }
    }
  };

  const handleCloseAlreadyEnrolledModal = () => {
    setShowAlreadyEnrolledModal(false);
  };

  const handleGoToFormation = () => {
    setShowAlreadyEnrolledModal(false);
    navigate("/eleve/formation", { replace: true });
  };

  const handleGoHome = () => {
    setShowAlreadyEnrolledModal(false);
    navigate("/", { replace: true });
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ivory px-5 py-10 font-body sm:px-8">
      <div
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-amber-light/40 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -left-32 bottom-0 h-72 w-72 rounded-full bg-coral-light/30 blur-3xl"
        aria-hidden="true"
      />

      <Link
        to="/"
        className="absolute left-5 top-6 z-10 inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-widest text-ink-soft transition-colors hover:text-coral-dark sm:left-8 sm:top-8"
      >
        <HiOutlineArrowLeft size={13} />{" "}{t("Retour au site")}</Link>

      <div className="relative mx-auto w-full max-w-5xl overflow-hidden rounded-4xl shadow-2xl shadow-brick/20 md:grid md:grid-cols-2">
        {/* ---------- PANNEAU ÉDITORIAL ---------- */}
        <AnimatedSection className="relative hidden flex-col justify-between overflow-hidden bg-linear-to-br from-brick via-coral to-amber p-1 md:flex">
          <div className="flex h-full flex-col justify-between rounded-[1.85rem] bg-ink/90  p-10">
            <div className="flex justify-center">
              {isDark ? <LogoVert width="200px" /> : <LogoBlanc width="200px"/>}
            </div>
            <div>
              <ValihaMotif count={24} tone="amber" className="h-20" />
              <p className="mt-4 font-body text-sm leading-relaxed text-ivory/60">{t("Apprends un instrument avec de vrais professeurs, à ton rythme, où que tu sois à Madagascar.")}</p>
              <div className="mt-6 flex items-center gap-3">
                <div className="flex -space-x-2">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="h-8 w-8 rounded-full border-2 border-ink bg-linear-to-br from-coral to-amber"
                    />
                  ))}
                </div>
                <div>
                  <p className="flex items-center gap-1 font-body text-sm font-semibold text-ivory">
                    4.8 <HiStar className="text-amber" size={13} />
                  </p>
                  <p className="font-mono text-[10px] uppercase tracking-wide text-ivory/50">{t("+1 000 élèves nous font confiance")}</p>
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>

        {/* ---------- FORMULAIRE ---------- */}
        <AnimatedSection delay={100} className="bg-white/90 dark:bg-white/10 p-8 sm:p-10">
          <div className="mb-8 flex gap-6 border-b border-ivory-dark">
            <NavLink
              to={"/connexionCompte"}
              className={({ isActive }) =>
                `relative pb-3 font-body text-sm font-semibold transition-colors duration-300 ${
                  isActive ? "text-ink" : "text-ink-soft hover:text-ink"
                }`
              }
            >{t("Se connecter")}<span
                className={({ isActive }) =>
                  `absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-coral transition-all duration-300 ${
                    isActive ? "text-ink" : "text-ink-soft hover:text-ink"
                  }`
                }
              />
            </NavLink>

            <NavLink
              to={"/inscriptionCompte"}
              className={({ isActive }) =>
                `relative pb-3 font-body text-sm font-semibold transition-colors duration-300 ${
                  isActive ? "text-ink" : "text-ink-soft hover:text-ink"
                }`
              }
            >{t("Créer un compte")}<span
                className={({ isActive }) =>
                  `absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-coral transition-all duration-300 ${
                    isActive ? "text-ink" : "text-ink-soft hover:text-ink"
                  }`
                }
              />
            </NavLink>
          </div>
          <form
            onSubmit={handleSubmit}
            key={"login"}
            className="animate-fade-in items-center"
          >
            <ActionFeedback action={action} />
            <FormField
              label={t("Adresse e-mail")}
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="fara.rakoto@mail.mg"
              icon={HiOutlineEnvelope}
              required
              className="mb-4"
            />

            <FormField
              label={t("Mot de passe")}
              type={showPassword ? "text" : "password"}
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="••••••••"
              icon={HiOutlineLockClosed}
              required
              className="mb-2"
              rightElement={
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="shrink-0 text-ink-soft transition-colors hover:text-ink"
                  aria-label={
                    showPassword
                      ? t("Masquer le mot de passe")
                      : t("Afficher le mot de passe")
                  }
                >
                  {showPassword ? (
                    <HiOutlineEyeSlash size={16} />
                  ) : (
                    <HiOutlineEye size={16} />
                  )}
                </button>
              }
            />

            <div className="mb-2 text-right">
              <button
                type="button"
                className="font-body text-xs font-medium text-coral-dark transition-colors hover:text-brick"
              >{t("Mot de passe oublié ?")}</button>
            </div>

            <button
              type="submit"
              className="group mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-coral py-3.5 font-body text-sm font-semibold text-ivory shadow-lg shadow-coral/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-coral-dark disabled:pointer-events-none disabled:opacity-70"
            >{t("Se connecter")}</button>
          </form>

          <p className="mt-6 text-center font-body text-xs text-ink-soft">{t("En continuant, tu acceptes les")}{" "}<button className="font-semibold text-coral-dark hover:text-brick">{t("conditions d'utilisation")}</button>{" "}{t("de la plateforme.")}</p>
        </AnimatedSection>
      </div>

      {/* ---------- MODALE : DÉJÀ INSCRIT À CE NIVEAU ---------- */}
      <Modal
        open={showAlreadyEnrolledModal}
        onClose={handleCloseAlreadyEnrolledModal}
        title={t("Déjà inscrit(e) à ce niveau")}
      >
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-amber-light/50 text-amber-dark">
            <HiOutlineCheckCircle size={28} />
          </div>

          <p className="font-body text-sm leading-relaxed text-ink-soft">
            {alreadyEnrolledNiveau ? (
              <>{t("Tu es déjà inscrit(e) au niveau")}{" "}<span className="font-semibold text-ink">
                  {alreadyEnrolledNiveau}
                </span>{t(". Tu peux continuer ta formation depuis ton tableau de bord.")}</>
            ) : (
              t("Tu es déjà inscrit(e) à ce niveau. Tu peux continuer ta formation depuis ton tableau de bord.")
            )}
          </p>

          <div className="mt-6 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={handleGoToFormation}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-coral py-3 font-body text-sm font-semibold text-ivory shadow-lg shadow-coral/25 transition-all duration-300 hover:-translate-y-0.5 hover:bg-coral-dark"
            >
              <HiOutlineAcademicCap size={16} />{t("Voir ma formation")}</button>
            <button
              type="button"
              onClick={handleGoHome}
              className="w-full rounded-full py-3 font-body text-sm font-semibold text-ink-soft transition-colors hover:text-ink"
            >{t("Retour à l'accueil")}</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
