import React from "react";
import {
  Routes,
  Route,
  Navigate,
  BrowserRouter,
  Outlet,
  useLocation,
} from "react-router-dom";
import { useEffect } from "react";

import Home from "./pages/home/Home";
import About from "./pages/home/About";
import Contact from "./pages/home/Contact";
import Courses from "./pages/home/Courses";
import HomeCourseDetail from "./pages/home/HomeCourseDetail";
import Instructors from "./pages/home/Instructors";
import Pricing from "./pages/home/Pricing";
import FAQ from "./pages/home/FAQ";
import NotFound from "./pages/home/NotFound";
import NiveauInscription from "./pages/home/Inscription";

import Dashboard from "./pages/eleve/Dashboard";
import Catalogue from "./pages/eleve/Catalogue";
import CoursDetail from "./pages/eleve/CoursDetail";
import LessonPlayer from "./pages/eleve/LessonPlayer";
import Progression from "./pages/eleve/Progression";
import Favoris from "./pages/eleve/Favoris";
import Messages from "./pages/eleve/Messages";
import Profil from "./pages/eleve/Profil";
import Parametres from "./pages/eleve/Parametres";
import Formation from "./pages/eleve/Formation";

import ProfDashboard from "./pages/professeur/Dashboard";
import ProfMesCours from "./pages/professeur/MesCours";
import ProfCourEditeur from "./pages/professeur/CourEditeur";
import ProfCorrections from "./pages/professeur/Corrections";
import ProfEleves from "./pages/professeur/Eleves";
import ProfMessages from "./pages/professeur/Messages";
import ProfParametres from "./pages/professeur/Parametres";
import ProfCoursDetail from "./pages/professeur/CoursDetail";
import ProfLeconEditeur from "./pages/professeur/LeconEditeur";
import ProfRessourceEditeur from "./pages/professeur/RessourceEditeur";
import ProfLeconDetail from "./pages/professeur/LeconDetail";
import ProfProfil from "./pages/professeur/Profil";

import AdminDashboard from "./pages/admin/Dashboard";
import AdminUtilisateurs from "./pages/admin/Utilisateurs";
import AdminValidation from "./pages/admin/Validation";
import AdminReferentiels from "./pages/admin/Referentiels";
import AdminPaiements from "./pages/admin/Paiements";
import AdminAvis from "./pages/admin/Avis";
import AdminParametres from "./pages/admin/Parametres";

import LayoutStudent from "./layouts/LayoutStudent";
import LayoutProf from "./layouts/LayoutProf";
import LayoutAdmin from "./layouts/LayoutAdmin";
import Navbar from "./layouts/Navbar";
import Footer from "./layouts/Footer";

import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";

import ProtectedRoute from "./components/ProtectedRoute";
import RoleRoute from "./components/RoleRoute";
import FormationDetail from "./pages/eleve/FormationDetail";
import FormationPublique from "./pages/home/FormationPublique";
import PaiementPublic from "./pages/home/PaiementPublic";
import Paiement from "./pages/eleve/Paiement";
import AdminProfil from "./pages/admin/Profil";
import CorrectionDetail from "./pages/professeur/CorrectionDetail";
import DetailProf from "./pages/home/DetailProf";

/** Remonte en haut de page à chaque changement de route */
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

/** Ossature commune à toutes les pages publiques : Navbar + contenu + Footer */
function HomeLayout() {
  return (
    <div className="flex min-h-screen flex-col bg-ivory">
      <ScrollToTop />
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    // <BrowserRouter>
    <Routes>
      <Route path="/connexionCompte" element={<Login />} />
      <Route path="/inscriptionCompte" element={<Register />} />
      <Route path="/profPage" element={<Navigate to="/professeur" replace />} />

      <Route element={<HomeLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/a-propos" element={<About />} />
        <Route path="/cours" element={<Courses />} />
        <Route path="/cours/:id" element={<HomeCourseDetail />} />
        <Route path="/professeurs" element={<Instructors />} />
        <Route path="/tarifs" element={<Pricing />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="professeurs/:id" element={<DetailProf />} />
        <Route
          path="/inscription"
          element={
            <RoleRoute allowedRole={"eleve"}>
              <NiveauInscription />
            </RoleRoute>
          }
        />
        <Route path="/formation" element={<FormationPublique />} />
        <Route path="/paiement" element={<PaiementPublic />} />

        <Route path="*" element={<NotFound />} />
      </Route>

      <Route
        path="/eleve"
        element={
          <RoleRoute allowedRole={"eleve"}>
            <LayoutStudent />
          </RoleRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="catalogue" element={<Catalogue />} />
        <Route path="formation/cours/:id" element={<CoursDetail />} />
        <Route path="formation/lecon/:id" element={<LessonPlayer />} />
        <Route path="progression" element={<Progression />} />
        <Route path="favoris" element={<Favoris />} />
        <Route path="messages" element={<Messages />} />
        <Route path="profil" element={<Profil />} />
        <Route path="parametres" element={<Parametres />} />
        <Route path="formation" element={<Formation />} />
        <Route path="paiement" element={<Paiement />} />

        {/* Route original à corriger le syntaxe */}
        <Route path="formation/:niveauName" element={<FormationDetail />} />
      </Route>

      <Route
        path="/professeur"
        element={
          <RoleRoute allowedRole={"professeur"}>
            <LayoutProf />
          </RoleRoute>
        }
      >
        <Route index element={<ProfDashboard />} />
        <Route path="mescours" element={<ProfMesCours />} />
        <Route path="cours/nouveau" element={<ProfCourEditeur />} />
        <Route path="cours/:id" element={<ProfCourEditeur />} />
        <Route path="corrections" element={<ProfCorrections />} />
        <Route path="corrections/:id" element={<CorrectionDetail />} />
        <Route path="eleves" element={<ProfEleves />} />
        <Route path="messages" element={<ProfMessages />} />
        <Route path="parametres" element={<ProfParametres />} />
        <Route path="cours/:id/details" element={<ProfCoursDetail />} />
        <Route path="cours/:id/lecons/nouveau" element={<ProfLeconEditeur />} />
        <Route
          path="cours/:id/lecons/:lessonId"
          element={<ProfLeconEditeur />}
        />
        <Route
          path="cours/:id/lecons/:lessonId/details"
          element={<ProfLeconDetail />}
        />
        <Route
          path="cours/:id/lecons/:lessonId/ressources/nouveau"
          element={<ProfRessourceEditeur />}
        />
        <Route
          path="cours/:id/lecons/:lessonId/ressources/:resourceId"
          element={<ProfRessourceEditeur />}
        />
        <Route path="profil" element={<ProfProfil />} />
      </Route>

      <Route
        path="/administrateur"
        element={
          <RoleRoute allowedRole={"admin"}>
            <LayoutAdmin />
          </RoleRoute>
        }
      >
        <Route index element={<AdminDashboard />} />
        <Route path="utilisateurs" element={<AdminUtilisateurs />} />
        <Route path="validation" element={<AdminValidation />} />
        <Route path="referentiels" element={<AdminReferentiels />} />
        <Route path="paiements" element={<AdminPaiements />} />
        <Route path="avis" element={<AdminAvis />} />
        <Route path="parametres" element={<AdminParametres />} />
        <Route path="profil" element={<AdminProfil />} />
      </Route>
    </Routes>
    // {/* </BrowserRouter> */}
  );
}
